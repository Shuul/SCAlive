# debug_for_all
Debug Warp  
Create Ship  
Add Research  
Add Blueprints  
Add Inventory  
Player Position  
Create Object  (most of the objects on the list cannot be created)  
DisplayGalaxy  

SIMPLE MENU API IS UNSTABLE  
https://github.com/bvbohnen/x4-simple-menu-api
